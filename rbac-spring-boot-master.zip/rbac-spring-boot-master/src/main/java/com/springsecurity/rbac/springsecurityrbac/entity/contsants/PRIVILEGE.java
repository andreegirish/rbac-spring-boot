package com.springsecurity.rbac.springsecurityrbac.entity.contsants;

public class PRIVILEGE {
    public static String READ = "READ";
    public static String WRITE = "WRITE";
    public static String UPDATE = "UPDATE";
    public static String DELETE = "DELETE";
}
