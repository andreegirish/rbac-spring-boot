package com.springsecurity.rbac.springsecurityrbac.entity.contsants;

public class PAGE {
    public static final String ROLE = "ROLE";

    public static final String USER = "USER";
    public static final String PRODUCT = "PRODUCT";
    public static final String USER_ROLE = "USER_ROLE";

}
